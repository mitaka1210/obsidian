<%*
const date = tp.date.now("YYYY-MM-DD");
const day = tp.date.now("dddd");
%>
---
tags: [лицеви]
date: <%= date %>
day: <%= day %>
type: pushups
total: 
series:
  - 
  - 
  - 
---

# 💪 Лицеви упори — <%= date %> (<%= day %>)

## 🔢 Серии:
- 1-ва: 
- 2-ра: 
- 3-та: 

## ✅ Общо: 
